require("dotenv").config();
const express = require("express");
const cors = require("cors");
const pool = require("./db");

const app = express();
app.use(cors());
app.use(express.json());


app.get("/", (req, res) => {
  res.send("API funcionando");
});

/* =========================
   ✅ PRODUCTOS
========================= */

// Obtener todos
app.get("/productos", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM productos");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Obtener por ID
app.get("/productos/:id", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM productos WHERE Codigo = ?", [
      req.params.id,
    ]);
    if (!rows.length)
      return res.status(404).json({ message: "Producto no encontrado" });

    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Crear
app.post("/productos", async (req, res) => {
  try {
    const { Nombre, Descripcion, Cantidad, Precio } = req.body;

    const [result] = await pool.query(
      "INSERT INTO productos (Nombre, Descripcion, Cantidad, Precio) VALUES (?, ?, ?, ?)",
      [Nombre, Descripcion, Cantidad, Precio]
    );

    res.json({ message: "Producto creado", id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Actualizar
app.put("/productos/:id", async (req, res) => {
  try {
    const { Nombre, Descripcion, Cantidad, Precio } = req.body;

    await pool.query(
      "UPDATE productos SET Nombre=?, Descripcion=?, Cantidad=?, Precio=? WHERE Codigo=?",
      [Nombre, Descripcion, Cantidad, Precio, req.params.id]
    );

    res.json({ message: "Producto actualizado" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Eliminar
app.delete("/productos/:id", async (req, res) => {
  try {
    await pool.query("DELETE FROM productos WHERE Codigo=?", [req.params.id]);
    res.json({ message: "Producto eliminado" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* =========================
   ✅ INVENTARIO
========================= */

// Obtener todos
app.get("/inventario", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM inventario");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Obtener por ID
app.get("/inventario/:id", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM inventario WHERE Codigo = ?", [
      req.params.id,
    ]);

    if (!rows.length)
      return res.status(404).json({ message: "Registro no encontrado" });

    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Crear
app.post("/inventario", async (req, res) => {
  try {
    const { Fecha, Cantidad, Tipo, ID_Producto, ID_Usuario } = req.body;

    const [result] = await pool.query(
      "INSERT INTO inventario (Fecha, Cantidad, Tipo, ID_Producto, ID_Usuario) VALUES (?, ?, ?, ?, ?)",
      [Fecha, Cantidad, Tipo, ID_Producto, ID_Usuario]
    );

    res.json({ message: "Registro agregado", id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Actualizar
app.put("/inventario/:id", async (req, res) => {
  try {
    const { Fecha, Cantidad, Tipo, ID_Producto, ID_Usuario } = req.body;

    await pool.query(
      "UPDATE inventario SET Fecha=?, Cantidad=?, Tipo=?, ID_Producto=?, ID_Usuario=? WHERE Codigo=?",
      [Fecha, Cantidad, Tipo, ID_Producto, ID_Usuario, req.params.id]
    );

    res.json({ message: "Registro actualizado" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Eliminar
app.delete("/inventario/:id", async (req, res) => {
  try {
    await pool.query("DELETE FROM inventario WHERE Codigo=?", [req.params.id]);
    res.json({ message: "Registro eliminado" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* =========================
   ✅ REPORTES
========================= */

// Obtener todos
app.get("/reportes", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM reportes");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Crear
app.post("/reportes", async (req, res) => {
  try {
    const { Fecha, Descripcion, ID_Usuario } = req.body;

    const [result] = await pool.query(
      "INSERT INTO reportes (Fecha, Descripcion, ID_Usuario) VALUES (?, ?, ?)",
      [Fecha, Descripcion, ID_Usuario]
    );

    res.json({ message: "Reporte creado", id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* =========================
   ✅ USUARIOS
========================= */

// Obtener todos
app.get("/usuarios", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM usuario");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Crear
app.post("/usuarios", async (req, res) => {
  try {
    const {
      Usuario,
      Nombre,
      Apellido,
      ID,
      F_Nacimiento,
      Correo_Electronico,
      Tipo,
    } = req.body;

    const [result] = await pool.query(
      "INSERT INTO usuario (Usuario, Nombre, Apellido, ID, F_Nacimiento, Correo_Electronico, Tipo) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [Usuario, Nombre, Apellido, ID, F_Nacimiento, Correo_Electronico, Tipo]
    );

    res.json({ message: "Usuario creado", id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Iniciar servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor corriendo en puerto ${PORT}`));

